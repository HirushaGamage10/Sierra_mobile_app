import 'package:sierra/screens/cart_page.dart';
import 'package:sierra/screens/favorite_page.dart';
import 'package:sierra/screens/screens/home%20Page/home_page.dart';
import 'package:sierra/screens/profile_page.dart';
import 'package:sierra/screens/screens/order_page.dart';
import 'package:flutter/material.dart';

class MainPage extends StatefulWidget {
  final Function(bool) toggleDarkMode;
  final bool isDarkMode;

  MainPage({required this.toggleDarkMode, required this.isDarkMode});

  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [];

  @override
  void initState() {
    super.initState();
    _pages.addAll([
      HomePage(),
      FavoritePage(),
      OrderPage(),
      CartPage(),
      ProfilePage(),
    ]);
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex], // Display selected page based on the index
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            _selectedIndex = 0; // Home page index
          });
        },
        shape: const CircleBorder(),
        backgroundColor: Colors.black,
        child: const Icon(
          Icons.home,
          color: Colors.white,
          size: 35,
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        elevation: 1,
        height: 60,
        color: const Color.fromRGBO(178, 151, 79, 1), // Updated BottomAppBar color
        shape: const CircularNotchedRectangle(),
        notchMargin: 10,
        clipBehavior: Clip.antiAliasWithSaveLayer,
        child: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(
              onPressed: () {
                _onItemTapped(1); // Navigate to the Cart Page
              },
              icon: Icon(
                Icons.favorite_border,
                size: 30,
                color: _selectedIndex == 1 ? Colors.white : const Color.fromARGB(255, 0, 0, 0), // Change selected icon color
              ),
            ),
            IconButton(
              onPressed: () {
                _onItemTapped(2); // Navigate to the Favorite Page
              },
              icon: Icon(
                Icons.assignment_rounded,
                size: 30,
                color: _selectedIndex == 2 ? Colors.white : const Color.fromARGB(255, 0, 0, 0), // Change selected icon color
              ),
            ),
            
            const SizedBox(width: 15), // Space for the FloatingActionButton
            IconButton(
              onPressed: () {
                _onItemTapped(3); // Navigate to the Cart Page
              },
              icon: Icon(
                Icons.shopping_cart_outlined,
                size: 30,
                color: _selectedIndex == 3 ? Colors.white : const Color.fromARGB(255, 0, 0, 0), // Change selected icon color
              ),
            ),
            IconButton(
              onPressed: () {
                _onItemTapped(4); // Navigate to the Profile Page
              },
              icon: Icon(
                Icons.person,
                size: 30,
                color: _selectedIndex == 4 ? Colors.white : const Color.fromARGB(255, 0, 0, 0), // Change selected icon color
              ),
            ),
          ],
        ),
      ),
    );
  }
}
