import 'screens/screens/signup_page.dart';
import 'screens/guest_page.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'widgets/theme_notifier.dart';
import 'screens/start_page.dart';
import 'screens/login_page.dart';
import 'widgets/navigation_bar.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => ThemeNotifier(),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeNotifier>(
      builder: (context, themeNotifier, child) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          theme: themeNotifier.isDarkMode ? ThemeData.dark() : ThemeData.light(),
          initialRoute: '/',
          routes: {
            '/': (context) => StartPage(toggleDarkMode: (bool ) {  }, isDarkMode: false,),
            '/guest': (context) => GuestPage(),
            '/login': (context) => LoginPage(),
            '/signUp': (context) => SignupPage(),
            '/home': (context) => MainPage(toggleDarkMode: (bool ) {  }, isDarkMode: false,),
          },
        );
      },
    );
  }
}
