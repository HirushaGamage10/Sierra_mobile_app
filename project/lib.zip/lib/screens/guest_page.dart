import 'package:sierra/screens/login_page.dart';
import 'package:sierra/screens/screens/signup_page.dart';
import 'package:flutter/material.dart';


class GuestPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background image
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/second.jpg'), // Background image
                fit: BoxFit.cover,
              ),
            ),
          ),
          // Content area with buttons and text
          Positioned(
            bottom: 100,
            left: 0,
            right: 0,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Sierra Text
                const Text(
                  'SIERRA',
                  style: TextStyle(
                    fontFamily: 'Poly',
                    fontStyle: FontStyle.italic,
                    fontSize: 60, // Adjust font size as needed
                    color: Colors.white, // Adjust color to match your design
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2, // Spacing between letters
                  ),
                ),
                const SizedBox(height: 40,),// Space between SIERRA and buttons
                // Create an Account button
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(320, 50),
                    backgroundColor: Colors.white, // Button background
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => SignupPage()),
                    );
                    
                  },
                  child: const Text(
                    'Create an Account',
                    style: TextStyle(
                    color: Colors.black, 
                    fontSize: 18),
                  ),
                ),

                const SizedBox(height: 20),
                // Continue as Guest button
                OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Colors.white), // White border
                    minimumSize: const Size(320, 50),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  onPressed: () {
                    Navigator.pushNamed(context, '/home');
                  },
                  child: const Text(
                    'Continue as guest',
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                ),
                const SizedBox(height: 30), 
                
                // Login link
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      'Already have an account? ',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),

                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => LoginPage()),
                    );
                        
                      },
                      child: const Text(
                        'Log In',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
