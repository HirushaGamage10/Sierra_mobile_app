import 'package:flutter/material.dart';

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background image
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/log.jpg'), // Background image
                fit: BoxFit.cover,
              ),
            ),
          ),
          Column(
            children: [
              // SIERRA text at the top
              const Padding(
                padding: EdgeInsets.only(top: 80.0), // Adjust top padding as needed
                child: Center(
                  child: Text(
                    'SIERRA',
                    style: TextStyle(
                      fontFamily: 'Poly',
                      fontStyle: FontStyle.italic,
                      fontSize: 36,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              const Spacer(), // This pushes the form to the bottom
              // Sign-up form
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30.0), // Add horizontal padding
                child: Column(
                  children: [
                    // Create New Account text
                    const Text(
                      'Welcome Back !',
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Email input field wrapped in a Container to set height
                    SizedBox(
                      height: 50, // Set height to 50px
                      child: TextField(
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                          hintText: 'Enter Email',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 20),

                    // Password input field wrapped in a Container to set height
                    SizedBox(
                      height: 50, // Set height to 50px
                      child: TextField(
                        obscureText: true,
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                          hintText: 'Password',
                          suffixIcon: const Icon(Icons.visibility_off),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 20),

                    // Sign In button
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        minimumSize: const Size(double.infinity, 50),
                        backgroundColor: const Color(0xFFD4AF37), // Gold color
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onPressed: () {
                        Navigator.pushNamed(context, '/home');
                      },
                      child: const Text(
                        'Log In',
                        style: TextStyle(
                          color: Colors.white,
                           fontSize: 18,
                           fontFamily: 'Poppins',
                           fontWeight: FontWeight.w900),
                      ),
                    ),

                    const SizedBox(height: 20),

                    // OR with small lines on both sides
                    const Row(
                      children: [
                        Expanded(
                          child: Divider(
                            color: Colors.white,
                            thickness: 2, // Line thickness
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8.0),
                          child: Text(
                            'or',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        Expanded(
                          child: Divider(
                            color: Colors.white,
                            thickness: 2, // Line thickness
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 10),

                    // Google and Facebook login buttons
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Google button
                        GestureDetector(
                          onTap: () {
                            // Handle Google sign-in
                          },
                          child: Image.asset(
                            'assets/icons/google.png', // Add the Google icon in assets
                            height: 40,
                          ),
                        ),
                        const SizedBox(width: 20),
                        // Facebook button
                        GestureDetector(
                          onTap: () {
                            // Handle Facebook sign-in
                          },
                          child: Image.asset(
                            'assets/icons/facebook.png', // Add the Facebook icon in assets
                            height: 40,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 100), // Adjust to add some space at the bottom
            ],
          ),
        ],
      ),
    );
  }
}
