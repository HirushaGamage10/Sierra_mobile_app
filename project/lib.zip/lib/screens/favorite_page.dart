import 'package:flutter/material.dart';

class FavoritePage extends StatelessWidget {
  final List<FavoriteItem> favoriteItems = [
    FavoriteItem(
      imageUrl: 'assets/images/product1.png',
      title: 'NIKE RUNNING SHIRT',
      subtitle: 'Men',
      price: 5000.0,
    ),
    FavoriteItem(
      imageUrl: 'assets/images/product5.png',
      title: 'PUMA HOODIE',
      subtitle: 'Men',
      price: 2000.0,
    ),
    FavoriteItem(
      imageUrl: 'assets/images/product4.png',
      title: 'EEBOK TRAINING SHIRT',
      subtitle: 'Men',
      price: 4000.0,
    ),
    
  ];

  FavoritePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text(
          'Favorites',
          style: TextStyle(
            fontFamily: 'Poly',
            fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic,
            fontSize: 28,
          ),
        ),
        centerTitle: true,
      ),
      body: ListView.builder(
        itemCount: favoriteItems.length,
        itemBuilder: (context, index) {
          final item = favoriteItems[index];
          return FavoriteCard(
            imageUrl: item.imageUrl,
            title: item.title,
            subtitle: item.subtitle,
            price: item.price,
            onDelete: () {
              // Handle delete action
              print('${item.title} removed from favorites');
            },
          );
        },
      ),
    );
  }
}

class FavoriteCard extends StatelessWidget {
  final String imageUrl;
  final String title;
  final String subtitle;
  final double price;
  final VoidCallback onDelete;

  const FavoriteCard({
    required this.imageUrl,
    required this.title,
    required this.subtitle,
    required this.price,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        elevation: 2,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Row(
            children: [
              // Product Image
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset(
                  imageUrl,
                  height: 70,
                  width: 70,
                  fit: BoxFit.cover,
                ),
              ),
              SizedBox(width: 12),
              // Product Info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                    Text(
                      subtitle,
                      style: TextStyle(color: Colors.grey),
                    ),
                    Text(
                      'Rs. ${price.toString()}',
                      style: TextStyle(fontSize: 16),
                    ),
                  ],
                ),
              ),
              // Delete Button
              IconButton(
                icon: Icon(Icons.delete, color: Colors.red),
                onPressed: onDelete,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class FavoriteItem {
  final String imageUrl;
  final String title;
  final String subtitle;
  final double price;

  FavoriteItem({
    required this.imageUrl,
    required this.title,
    required this.subtitle,
    required this.price,
  });
}

